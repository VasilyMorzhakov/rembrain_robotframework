from enum import IntEnum


class PackType(IntEnum):
    JPG_PNG = 1
    JPG = 2
